import { useState } from "react";
import { useNavigate, Link as RouterLink } from "react-router-dom";
import axios from "axios";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Alert,
  Link,
  Stack,
} from "@mui/material";
import { useAuth } from "../../hooks/useAuth";
import PageTemplate from "../../components/PageTemplate";
import {
  isCandidateLikeRole,
  isCoreStaffRole,
  normalizeRole,
} from "../../utils/roleGroups";

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const result = await login(email, password);
      const role = normalizeRole(result?.role);

      if (["declic_staff"].includes(role)) {
        navigate("/dashboard/declic", { replace: true });
      } else if (["prepa_staff"].includes(role)) {
        navigate("/dashboard/prepa", { replace: true });
      } else if (isCoreStaffRole(role)) {
        navigate("/dashboard", { replace: true });
      } else if (isCandidateLikeRole(role)) {
        navigate("/dashboard/candidat", { replace: true });
      } else {
        navigate("/dashboard", { replace: true });
      }
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        const status = err.response?.status;
        const data = err.response?.data as
          | { detail?: string; message?: string }
          | undefined;
        const attemptedUrl = `${err.config?.baseURL ?? ""}${err.config?.url ?? ""}`;

        let msg = data?.detail || data?.message || "Connexion impossible.";

        if (!err.response) {
          msg =
            "Impossible de joindre le backend. Vérifiez que Django est démarré.";
        } else if (status === 400 || status === 401) {
          msg = data?.detail || data?.message || "Identifiants incorrects.";
        } else if (status === 404) {
          msg = `Endpoint de connexion introuvable (${attemptedUrl || "URL inconnue"}).`;
        } else if (status && status >= 500) {
          msg = "Le backend a rencontré une erreur pendant la connexion.";
        }

        setError(msg);
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("Erreur inconnue");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageTemplate centered maxWidth="sm" hero={false}>
      <Paper
        elevation={0}
        sx={{
          width: "100%",
          maxWidth: 400,
          mx: "auto",
          p: { xs: 2.5, sm: 4 },
        }}
      >
        <Stack spacing={2.5}>
          <Box>
            <Typography
              variant="h5"
              component="h1"
              align="center"
              gutterBottom
            >
              Se connecter
            </Typography>

            <Typography variant="body2" color="text.secondary" align="center">
              Accédez à votre espace en saisissant vos identifiants.
            </Typography>
          </Box>

          <Box component="form" onSubmit={handleSubmit} noValidate>
            <Stack spacing={2}>
              <TextField
                label="Adresse email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                fullWidth
                required
                autoFocus
              />

              <TextField
                label="Mot de passe"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                fullWidth
                required
              />

              {error && <Alert severity="error">{error}</Alert>}

              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
                disabled={loading}
              >
                {loading ? "Connexion..." : "Se connecter"}
              </Button>
            </Stack>
          </Box>

          <Typography variant="body2" align="center">
            Pas encore de compte ?{" "}
            <Link component={RouterLink} to="/register">
              Créer un compte
            </Link>
          </Typography>

          <Typography
            variant="caption"
            align="center"
            display="block"
            color="text.secondary"
          >
            En vous connectant, vous acceptez nos{" "}
            <Link
              component={RouterLink}
              to="/politique-confidentialite"
              target="_blank"
            >
              conditions de confidentialité
            </Link>
            .
          </Typography>
        </Stack>
      </Paper>
    </PageTemplate>
  );
}