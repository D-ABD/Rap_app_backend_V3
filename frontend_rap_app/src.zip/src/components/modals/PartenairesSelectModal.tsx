import { useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  CircularProgress,
  Box,
  Grid,
  Typography,
  Chip,
  Stack,
  Divider,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { toast } from "react-toastify";
import axios, { AxiosError } from "axios";
import api from "../../api/axios";
import type { Partenaire } from "../../types/partenaire";
import type { AppTheme } from "../../theme";
import SearchInput from "../SearchInput";

/* ---------- Types ---------- */
interface Props {
  show: boolean;
  onClose: () => void;
  onSelect: (partenaire: Partenaire) => void;
  onCreate?: (payload: CreatePartPayload, opts?: { reuse?: boolean }) => Promise<PartenaireMinimal>;
  prospectionId?: number;
}

type PartenaireMinimal = {
  id: number;
  nom: string;
  type: string;
  secteur_activite?: string | null;
  city?: string | null;
  zip_code?: string | null;
  contact_nom?: string | null;
  contact_email?: string | null;
  contact_telephone?: string | null;
  website?: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

type CreatePartPayload = {
  nom: string;
  type?: string | null;
  secteur_activite?: string | null;
  street_name?: string | null;
  zip_code?: string | null;
  city?: string | null;
  country?: string | null;
  contact_nom?: string | null;
  contact_poste?: string | null;
  contact_telephone?: string | null;
  contact_email?: string | null;
  website?: string | null;
  social_network_url?: string | null;
  actions?: string | null;
  action_description?: string | null;
  description?: string | null;
};

type ListResponse<T> = {
  results: T[];
  count?: number;
  next?: string | null;
  previous?: string | null;
};
type ApiListEnvelope<T> = { data: ListResponse<T> } | ListResponse<T> | T[];

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null;
}
function toArray<T>(payload: ApiListEnvelope<T>): T[] {
  if (Array.isArray(payload)) return payload;
  if (isRecord(payload) && "data" in payload && isRecord((payload as { data: unknown }).data)) {
    const d = (payload as { data: unknown }).data as ListResponse<T>;
    return Array.isArray(d.results) ? d.results : [];
  }
  if (isRecord(payload) && "results" in payload) {
    const d = payload as ListResponse<T>;
    return Array.isArray(d.results) ? d.results : [];
  }
  return [];
}

type ApiEnvelope<T> = { data: T } | T;
function unwrap<T>(payload: ApiEnvelope<T>): T {
  return isRecord(payload) && "data" in payload ? (payload as { data: T }).data : (payload as T);
}

function compact(parts: Array<string | null | undefined>): string {
  return parts.filter((part): part is string => typeof part === "string" && part.trim() !== "").join(" • ");
}

function getDepartementLabel(zipCode?: string | null): string | null {
  if (!zipCode) return null;
  const digits = zipCode.replace(/\s+/g, "");
  if (/^97\d{2}$/.test(digits) || /^98\d{2}$/.test(digits)) return digits.slice(0, 3);
  if (/^\d{5}$/.test(digits)) return digits.slice(0, 2);
  return null;
}

function getPartenaireLocation(partenaire: Pick<Partenaire, "city" | "zip_code">): string | null {
  const departement = getDepartementLabel(partenaire.zip_code);
  return compact([
    partenaire.city ?? null,
    departement ? `Dpt ${departement}` : null,
    partenaire.zip_code ?? null,
  ]);
}

function getPartenaireSummary(partenaire: Partenaire): string {
  return compact([
    partenaire.type_display ?? partenaire.type ?? null,
    partenaire.secteur_activite ?? null,
    partenaire.contact_nom ?? null,
    partenaire.contact_email ?? partenaire.contact_telephone ?? null,
  ]);
}

/* ---------- Component ---------- */
export default function PartenaireSelectModal({
  show,
  onClose,
  onSelect,
  onCreate,
  prospectionId,
}: Props) {
  const theme = useTheme<AppTheme>();
  const isLight = theme.palette.mode === "light";

  const [partenaires, setPartenaires] = useState<Partenaire[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [search, setSearch] = useState("");
  const [creating, setCreating] = useState(false);

  // mini-form création
  const [nom, setNom] = useState("");
  const [type, setType] = useState("");
  const [city, setCity] = useState("");
  const [zip, setZip] = useState("");
  const [email, setEmail] = useState("");
  const [tel, setTel] = useState("");

  const dialogSectionTokens = theme.custom.dialog.section;
  const sectionBackground = isLight
    ? dialogSectionTokens.background.light
    : dialogSectionTokens.background.dark;
  const sectionBorder = isLight
    ? dialogSectionTokens.border.light
    : dialogSectionTokens.border.dark;

  const sectionTitleBackground = isLight
    ? theme.custom.overlay.modalSectionTitle.background.light
    : theme.custom.overlay.modalSectionTitle.background.dark;
  const sectionTitleBorder = isLight
    ? theme.custom.overlay.modalSectionTitle.borderBottom.light
    : theme.custom.overlay.modalSectionTitle.borderBottom.dark;

  const sectionContainerSx = {
    border: sectionBorder,
    borderRadius: dialogSectionTokens.borderRadius,
    background: sectionBackground,
    overflow: "hidden",
  } as const;

  const sectionHeaderSx = {
    px: dialogSectionTokens.padding,
    py: 1,
    background: sectionTitleBackground,
    borderBottom: sectionTitleBorder,
  } as const;

  useEffect(() => {
    if (!show) return;
    setLoading(true);
    api
      .get<ApiListEnvelope<Partenaire>>("/partenaires/", {
        params: { page_size: 100 },
      })
      .then((res) => {
        setPartenaires(toArray<Partenaire>(res.data));
        setError(false);
      })
      .catch(() => {
        setError(true);
        setPartenaires([]);
      })
      .finally(() => setLoading(false));
  }, [show]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return partenaires.filter(
      (p) => p.nom.toLowerCase().includes(q) || (!!p.city && p.city.toLowerCase().includes(q))
    );
  }, [partenaires, search]);

  const canCreate = true;
  const createDisabled = creating || nom.trim() === "";

  const handleCreate = async () => {
    if (!canCreate) return;
    setCreating(true);
    try {
      const payload: CreatePartPayload = {
        nom: nom.trim(),
        type: type.trim() || null,
        city: city.trim() || null,
        zip_code: zip.trim() || null,
        contact_email: email.trim() || null,
        contact_telephone: tel.trim() || null,
      };

      let created: PartenaireMinimal;
      if (onCreate) {
        created = await onCreate(payload, { reuse: true });
      } else if (typeof prospectionId === "number") {
        const res = await api.post<ApiEnvelope<PartenaireMinimal>>(
          `/prospections/${prospectionId}/creer-partenaire/`,
          payload,
          { params: { reuse: true } }
        );
        created = unwrap<PartenaireMinimal>(res.data);
      } else {
        const res = await api.post<ApiEnvelope<PartenaireMinimal>>("/partenaires/", payload);
        created = unwrap<PartenaireMinimal>(res.data);
      }

      toast.success("Partenaire créé et sélectionné.");
      onSelect(created as Partenaire);
      onClose();
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        const detail = (err as AxiosError<{ detail?: string }>).response?.data?.detail;
        if (typeof detail === "string") {
          if (detail.toLowerCase().includes("centre")) {
            toast.error(`${detail} Contacte un administrateur si besoin.`);
          } else {
            toast.error(detail);
          }
        } else {
          toast.error("Le partenaire n'a pas pu être créé.");
        }
      } else {
        toast.error("Le partenaire n'a pas pu être créé.");
      }
    } finally {
      setCreating(false);
    }
  };

  return (
    <Dialog open={show} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>Sélectionner un partenaire</DialogTitle>

      <DialogContent>
        <Stack spacing={2}>
          <SearchInput
            type="text"
            placeholder="Rechercher par nom ou ville..."
            value={search}
            onChange={(ev) => setSearch(ev.target.value)}
            fullWidth
          />

          <Box sx={sectionContainerSx}>
            <Box sx={sectionHeaderSx}>
              <Typography variant="subtitle2" fontWeight={700}>
                Partenaires disponibles
              </Typography>
            </Box>

            <Box sx={{ p: dialogSectionTokens.padding }}>
              {loading ? (
                <Box sx={{ display: "flex", justifyContent: "center", py: 2 }}>
                  <CircularProgress />
                </Box>
              ) : error ? (
                <Typography color="error">Les partenaires n'ont pas pu être chargés.</Typography>
              ) : filtered.length === 0 ? (
                <Typography color="text.secondary">Aucun partenaire trouvé.</Typography>
              ) : (
                <List disablePadding>
                  {filtered.map((partenaire, index) => (
                    <Box key={partenaire.id}>
                      <ListItem disablePadding>
                        <ListItemButton onClick={() => onSelect(partenaire)}>
                          <ListItemText
                            disableTypography
                            primary={
                              <Stack
                                direction="row"
                                spacing={1}
                                alignItems="center"
                                useFlexGap
                                flexWrap="wrap"
                              >
                                <Typography variant="body2" component="span" fontWeight={700}>
                                  {partenaire.nom}
                                </Typography>

                                {partenaire.type_display ? (
                                  <Chip
                                    size="small"
                                    label={partenaire.type_display}
                                    variant="outlined"
                                  />
                                ) : null}

                                {!partenaire.is_active ? (
                                  <Chip size="small" color="warning" label="Archivé" />
                                ) : null}
                              </Stack>
                            }
                            secondary={
                              <Box
                                sx={{
                                  mt: 0.5,
                                  display: "flex",
                                  flexDirection: "column",
                                  gap: 0.25,
                                }}
                              >
                                {getPartenaireLocation(partenaire) ? (
                                  <Typography variant="body2" component="div">
                                    {getPartenaireLocation(partenaire)}
                                  </Typography>
                                ) : null}

                                {getPartenaireSummary(partenaire) ? (
                                  <Typography
                                    variant="body2"
                                    component="div"
                                    color="text.secondary"
                                  >
                                    {getPartenaireSummary(partenaire)}
                                  </Typography>
                                ) : (
                                  <Typography
                                    variant="body2"
                                    component="div"
                                    color="text.secondary"
                                  >
                                    Aucun complément renseigné.
                                  </Typography>
                                )}
                              </Box>
                            }
                          />
                        </ListItemButton>
                      </ListItem>

                      {index < filtered.length - 1 ? <Divider /> : null}
                    </Box>
                  ))}
                </List>
              )}
            </Box>
          </Box>

          {canCreate && (
            <Box sx={sectionContainerSx}>
              <Box sx={sectionHeaderSx}>
                <Typography variant="subtitle2" fontWeight={700}>
                  Créer et lier un partenaire
                </Typography>
              </Box>

              <Box sx={{ p: dialogSectionTokens.padding }}>
                <Grid container spacing={1.5}>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Nom *"
                      value={nom}
                      onChange={(e) => setNom(e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Type"
                      value={type}
                      onChange={(e) => setType(e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Ville"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Code postal / département"
                      value={zip}
                      onChange={(e) => setZip(e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Email contact"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Téléphone contact"
                      value={tel}
                      onChange={(e) => setTel(e.target.value)}
                    />
                  </Grid>
                </Grid>

                <Box sx={{ mt: 1.5 }}>
                  <Button onClick={handleCreate} disabled={createDisabled}>
                    {creating ? "Création…" : "Créer et sélectionner"}
                  </Button>
                </Box>
              </Box>
            </Box>
          )}
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} color="secondary">
          Fermer
        </Button>
      </DialogActions>
    </Dialog>
  );
}